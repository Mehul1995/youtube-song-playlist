package com.mehul.action;

import com.opensymphony.xwork2.ActionSupport;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SignupAction extends ActionSupport{

	/**
	 * validate for the sign up page and storing in DB
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	public String user;
	public String password;
	public String confirmpassword;
	public String name;
	
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getConfirmpassword() {
		return confirmpassword;
	}


	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}

	
	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getUser() {
		return user;
	}


	public void setUser(String user) {
		this.user = user;
	}
	
	 public String execute() {
	      String ret = ERROR;
	      Connection conn = null;

	      try {
	         String URL = "jdbc:mysql://localhost/strut2_db";
	         Class.forName("com.mysql.jdbc.Driver");
	         conn = DriverManager.getConnection(URL, "root", "root1234");
	         String sql = "INSERT INTO login VALUES ";
	         sql+=" ( ? ,  ? ,  ? )";
	         PreparedStatement ps = conn.prepareStatement(sql);
	         ps.setString(1, user);
	         ps.setString(2, password);
	         ps.setString(3, name);
	        int i= ps.executeUpdate();
	        
	        System.out.println("i value is the:"+i);
	        if(i==1){
	        	return SUCCESS;
	        }
	      
	      } catch (Exception e) {
	         ret = ERROR;
	      } finally {
	         if (conn != null) {
	            try {
	               conn.close();
	            } catch (Exception e) {
	            }
	         }
	      }
	      return ret;
	   }
		
	@Override
	public void validate(){
		
		if("".equals(getUser())){
			addFieldError("user", getText("user.required"));
		}
		if("".equals(getName())){
			addFieldError("name", getText("name.required"));
		}
		
		if("".equals(getPassword())){
			addFieldError("password", getText("password.required"));
		}
		if("".equals(getConfirmpassword())){
			addFieldError("confirmpassword", getText("confirmpassword.required"));
		}
		
		
		if(!(getPassword().equals(getConfirmpassword()))){
			addFieldError("confirmpassword", getText("confirmpassword.notmatch"));
		}
		
		}
		
		
	
	
}
