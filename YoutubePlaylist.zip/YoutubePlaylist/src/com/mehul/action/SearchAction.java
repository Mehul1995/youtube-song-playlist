package com.mehul.action;

import com.opensymphony.xwork2.ActionSupport;

public class SearchAction extends ActionSupport{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String Search;

	
	public String getSearch() {
		return Search;
	}



	public void setSearch(String search) {
		Search = search;
	}
	


public String execute(){
		
	if(Search.equals("hollywood hits"))
	{
		return "hhits";
	}
	else if (Search.equals("bollywood hits"))
	{
		return "bhits";
	}
	else if (Search.equals("tamil hits"))
	{
		return "thits";
	}
	
	else
		return ERROR;
}


}
